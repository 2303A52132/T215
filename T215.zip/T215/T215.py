import tkinter as tk
from tkinter import ttk, messagebox

def recommend_fertilizer():
    try:
        ph = float(ph_entry.get())
        nitrogen = float(nitrogen_entry.get())
        phosphorus = float(phosphorus_entry.get())
        potassium = float(potassium_entry.get())
        temperature = float(temp_entry.get())
        rainfall = float(rain_entry.get())
        crop = crop_var.get()

        recommendation = ""

        # Rule-based fertilizer recommendations
        if crop == "Wheat":
            if nitrogen < 60:
                recommendation += "Apply Urea (high in nitrogen) - 100kg/acre.\n"
            if phosphorus < 45:
                recommendation += "Apply Single Super Phosphate - 50kg/acre.\n"
            if potassium < 35:
                recommendation += "Apply Muriate of Potash - 30kg/acre.\n"

        elif crop == "Rice":
            if nitrogen < 70:
                recommendation += "Apply Urea - 120kg/acre.\n"
            if phosphorus < 50:
                recommendation += "Apply DAP (Di-Ammonium Phosphate) - 60kg/acre.\n"
            if potassium < 40:
                recommendation += "Apply Potassium Sulphate - 35kg/acre.\n"

        elif crop == "Maize":
            if nitrogen < 80:
                recommendation += "Apply Urea - 130kg/acre.\n"
            if phosphorus < 40:
                recommendation += "Apply DAP - 55kg/acre.\n"
            if potassium < 30:
                recommendation += "Apply Potash - 25kg/acre.\n"

        elif crop == "Soybean":
            if nitrogen < 50:
                recommendation += "Soybeans fix nitrogen; apply minimal Urea (20kg/acre).\n"
            if phosphorus < 40:
                recommendation += "Apply Rock Phosphate - 50kg/acre.\n"
            if potassium < 30:
                recommendation += "Apply MOP - 20kg/acre.\n"

        # Weather impact tips
        if temperature > 35:
            recommendation += "\nHigh temperature detected: Avoid excess nitrogen to prevent burning."
        if rainfall > 200:
            recommendation += "\nHeavy rainfall detected: Use slow-release fertilizers to prevent leaching."

        if not recommendation:
            recommendation = "Your inputs suggest soil is well-balanced for this crop. Use organic compost for maintenance."

        messagebox.showinfo("Fertilizer Recommendation", recommendation)

    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numeric values for soil and weather conditions.")

# GUI setup
root = tk.Tk()
root.title("Sustainable Fertilizer Usage Optimizer")
root.geometry("420x600")
root.configure(bg="#f0f4f7")

# Heading
heading = tk.Label(root, text="🌿 Sustainable Fertilizer Usage Optimizer", font=("Helvetica", 16, "bold"), bg="#4CAF50", fg="white", pady=10)
heading.pack(fill="x")

# Form Frame
form_frame = tk.Frame(root, bg="#f0f4f7", padx=20, pady=20)
form_frame.pack(pady=10)

def create_label_entry(text):
    label = ttk.Label(form_frame, text=text)
    label.pack(anchor='w', pady=(10, 2))
    entry = ttk.Entry(form_frame, width=30)
    entry.pack()
    return entry

# Inputs
ph_entry = create_label_entry("Soil pH:")
nitrogen_entry = create_label_entry("Nitrogen Level (ppm):")
phosphorus_entry = create_label_entry("Phosphorus Level (ppm):")
potassium_entry = create_label_entry("Potassium Level (ppm):")
temp_entry = create_label_entry("Temperature (°C):")
rain_entry = create_label_entry("Rainfall (mm):")

# Crop selection
ttk.Label(form_frame, text="Select Crop:").pack(anchor='w', pady=(10, 2))
crop_var = tk.StringVar()
crop_menu = ttk.Combobox(form_frame, textvariable=crop_var, values=["Wheat", "Rice", "Maize", "Soybean"], width=28)
crop_menu.pack()
crop_menu.current(0)

# Submit button
recommend_button = ttk.Button(root, text="🌱 Get Recommendation", command=recommend_fertilizer)
recommend_button.pack(pady=30)

# Footer
footer = tk.Label(root, text="Developed by Team 215", bg="#f0f4f7", font=("Arial", 9, "italic"), fg="#777")
footer.pack(side="bottom", pady=10)

# Run the app
root.mainloop()
